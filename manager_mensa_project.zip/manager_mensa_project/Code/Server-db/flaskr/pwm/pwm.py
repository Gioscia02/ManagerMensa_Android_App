from flask import (
    Blueprint, flash, g, redirect, render_template, 
    request, session, url_for, jsonify, current_app
)
from . import db
import mysql.connector
from mysql.connector import Error, IntegrityError

bp = Blueprint('pwm', __name__, url_prefix='/pwm')

@bp.route('/user', methods=['GET'], endpoint='get_users')
def get_users():
    connection = db.getdb()
    resp = []
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM User")
        users = cursor.fetchall()
        for user in users:
            resp.append({
                'id': user['idUser'],
                'username': user['username'], 
                'password': user['password'], 
                'nome': user['nome'],
                'cognome': user['cognome']
            })
    except IntegrityError:
        resp.append({'error': 'Error retrieving users'})
    finally:        
        cursor.close()
    return jsonify(resp)

@bp.route('/hotels', methods=['GET'], endpoint='get_hotels')
def get_hotels():
    connection = db.getdb()
    resp = []
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM hotels")
        hotels = cursor.fetchall()
        for hotel in hotels:
            resp.append({
                'id': hotel['id'],
                'hotel_name': hotel['hotel_name'], 
                'addressline1': hotel['addressline1'], 
                'city': hotel['city'],
                'state': hotel['state'],
                'country': hotel['country'],
                'star_rating': hotel['star_rating'],
                'checkin': hotel['checkin'],
                'checkout': hotel['checkout'],
                'numberrooms': hotel['numberrooms'],
                'overview': hotel['overview'],
                'number_of_reviews': hotel['number_of_reviews'],
                'rating_average': hotel['rating_average'],
                'img': hotel['img'],
                'rates_currency': hotel['rates_currency']
            })
    except IntegrityError:
        resp.append({'error': 'Error retrieving hotels'})
    finally:        
        cursor.close()
    return jsonify(resp)

@bp.route('/user/<int:user_id>', methods=['GET'], endpoint='get_user')
def get_user(user_id):
    connection = db.getdb()
    resp = {}
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM User WHERE idUser = %s", (user_id,))
        user = cursor.fetchone()
        if user:
            resp = {
                'id': user['idUser'],
                'username': user['username'], 
                'password': user['password'], 
                'nome': user['nome'],
                'cognome': user['cognome']
            }
        else:
            resp = {'error': 'User not found'}
    except IntegrityError:
        resp = {'error': 'Error retrieving user'}
    finally:
        cursor.close()
    return jsonify(resp)

@bp.route('/utenti', methods=['POST'], endpoint='insert_user')
def insert_user():
    nascita = request.json.get('nascita')
    password = request.json.get('password')
    nome = request.json.get('nome')
    cognome = request.json.get('cognome')
    mail = request.json.get('email')
    connection = db.getdb()
    try:
        cursor = connection.cursor()
        cursor.execute(
            "INSERT INTO utenti (nome, cognome, nascita, email, password) VALUES (%s, %s, %s, %s, %s)",
            (nome, cognome, nascita, mail, password)
        )
        connection.commit()
        user_id = cursor.lastrowid
        resp = {'nome': nome, 'cognome': cognome, 'nascita': nascita, 'email': mail, 'password': password}
    except IntegrityError:
        resp = {'error': 'Error inserting user'}
    finally:
        cursor.close()
    return jsonify(resp)

@bp.route('/utenti', methods=['GET'], endpoint='create_user')
def create_user():
    nascita = request.json.get('nascita')
    password = request.json.get('password')
    nome = request.json.get('nome')
    cognome = request.json.get('cognome')
    email = request.json.get('email')
    connection = db.getdb()
    try:
        cursor = connection.cursor()
        cursor.execute(
            "INSERT INTO utenti (nome, cognome, nascita, email, password) VALUES (%s, %s, %s, %s, %s)",
            (nome, cognome, nascita, email, password)
        )
        connection.commit()
        user_id = cursor.lastrowid
        resp = {'success': True, 'user_id': user_id}
    except IntegrityError:
        resp = {'error': 'Error creating user'}
    finally:
        cursor.close()
    return jsonify(resp)

@bp.route('/utenti/segnalazione', methods=['POST'], endpoint='create_segnalazione')
def create_segnalazione():
    argomento = request.json.get('argomento')
    testo = request.json.get('testo')
    email = request.json.get('email')
    connection = db.getdb()
    try:
        cursor = connection.cursor()
        cursor.execute(
            "INSERT INTO segnalazioni (email, argomento, testo) VALUES (%s, %s, %s)",
            (email, argomento, testo)
        )
        connection.commit()
        user_id = cursor.lastrowid
        resp = {'success': True, 'user_id': user_id}
    except IntegrityError:
        resp = {'error': 'Error creating segnalazione'}
    finally:
        cursor.close()
    return jsonify(resp)

@bp.route('/utenti/prenotazione', methods=['POST'], endpoint='create_prenotazione')
def create_prenotazione():
    email = request.json.get('email')
    giorno = request.json.get('giorno')
    orario = request.json.get('orario')
    pasto = request.json.get('pasto')
    connection = db.getdb()
    try:
        cursor = connection.cursor()
        cursor.execute(
            "INSERT INTO prenotazioni (email, giorno, orario, pasto) VALUES (%s,%s,%s,%s)",
            (email, giorno, orario, pasto)
        )
        connection.commit()
        user_id = cursor.lastrowid
        resp = {'success': True, 'user_id': user_id}
    except IntegrityError:
        resp = {'success': False}
    finally:
        cursor.close()
    return jsonify(resp)

@bp.route('/utenti/prenotazione', methods=['GET'], endpoint='get_prenotazioni')
def get_prenotazioni():
    connection = db.getdb()
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM prenotazioni")
        prenotazioni = cursor.fetchall()
        resp = []
        for p in prenotazioni:
            resp.append({
                'email': p['email'],
                'giorno': p['giorno'], 
                'orario': p['orario'], 
                'pasto': p['pasto']
            })
    except IntegrityError:
        resp = {}
    finally:
        cursor.close()
    return jsonify(resp)

@bp.route('/utenti/<string:email>/<string:password>', methods=['GET'], endpoint='get_userr')
def get_userr(email, password):
    connection = db.getdb()
    resp = {}
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM utenti WHERE email = %s and password = %s", (email, password))
        user = cursor.fetchone()
        if user:
            resp = {
                'nome': user['nome'],
                'cognome': user['cognome'],
                'email': user['email'],
                'password': user['password'],
                'nascita': user['nascita']
            }
        else:
            resp = {}
    except IntegrityError:
        resp = {'error': 'Error retrieving user'}
    finally:
        cursor.close()
    return jsonify(resp)

@bp.route('/utenti/aggiornautente', methods=['PUT'], endpoint='update_user')
def update_user():
    emailattuale = request.json.get('emailattuale')
    emailnuova = request.json.get('emailnuova')
    password = request.json.get('password')
    nome = request.json.get('nome')
    cognome = request.json.get('cognome')
    nascita = request.json.get('nascita')
    connection = db.getdb()
    try:
        cursor = connection.cursor()
        cursor.execute(
            "UPDATE utenti SET email = %s, password = %s, nome = %s, cognome = %s, nascita = %s WHERE email = %s",
            (emailnuova, password, nome, cognome, nascita, emailattuale)
        )
        connection.commit()
        resp = {'email': emailnuova, 'password': password}
    except IntegrityError:
        resp = {'error': 'Error updating user'}
    finally:
        cursor.close()
    return jsonify(resp)

@bp.route('/user/<int:user_id>', methods=['DELETE'], endpoint='delete_user')
def delete_user(user_id):
    connection = db.getdb()
    try:
        cursor = connection.cursor()
        cursor.execute("DELETE FROM User WHERE idUser = %s", (user_id,))
        connection.commit()
        resp = {'message': 'User deleted successfully'}
    except IntegrityError:
        resp = {'error': 'Error deleting user'}
    finally:
        cursor.close()
    return jsonify(resp)



@bp.route('/utenti/prezzi', methods=['GET'], endpoint='get_prezzi')
def get_prezzi():
    connection = db.getdb()
    resp = {}
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM prezzi")
        user = cursor.fetchone()
        if user:
            resp = {
                'prezzo_pranzo_completo': user['prezzo_pranzo_completo'],
                'prezzo_cena_completa': user['prezzo_cena_completa'],
                'prezzo_primo': user['prezzo_primo'],
                'prezzo_secondo': user['prezzo_secondo'],
                'prezzo_contorno': user['prezzo_contorno']
            }
        else:
            resp = {}
    except IntegrityError:
        resp = {'error': 'Error retrieving prezzi'}
    finally:
        cursor.close()
    return jsonify(resp)

@bp.route('/utenti/transazione', methods=['POST'], endpoint='insert_transazione')
def insert_transazione():
    email = request.json.get('email')
    tipo = request.json.get('tipo')
    quantita = request.json.get('quantita')
    connection = db.getdb()
    try:
        cursor = connection.cursor()
        cursor.execute(
            "INSERT INTO transazioni (email, tipo, quantita) VALUES (%s,%s,%s)",
            (email, tipo, quantita)
        )
        connection.commit()
        user_id = cursor.lastrowid
        resp = {'success': True, 'user_id': user_id}
    except IntegrityError:
        resp = {}
    finally:
        cursor.close()
    return jsonify(resp)

@bp.route('/utenti/saldo/<string:email>', methods=['GET'], endpoint='get_saldo')
def get_saldo(email):
    connection = db.getdb()
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT SUM(quantita) AS saldo_totale FROM transazioni WHERE email = %s", (email,))
        saldo_totale = cursor.fetchone()
        if saldo_totale and saldo_totale['saldo_totale'] is not None:
            resp = {'saldo_totale': saldo_totale['saldo_totale']}
        else:
            resp = {'saldo_totale': 0, 'email': email}
    except IntegrityError:
        resp = {}
    finally:
        cursor.close()
    return jsonify(resp)

@bp.route('/utenti/transazioni/<string:email>', methods=['GET'], endpoint='get_transazioni')
def get_transazioni(email):
    connection = db.getdb()
    try:
        resp = []
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM transazioni WHERE email = %s", (email,))
        transazioni = cursor.fetchall()
        for transazione in transazioni:
            resp.append({
                'email': transazione['email'],
                'tipo': transazione['tipo'],
                'quantita': transazione['quantita'],
                'data': transazione['data_esecuzione']
            })
    except IntegrityError:
        resp = {}
    finally:
        cursor.close()
    return jsonify(resp)


import logging

@bp.route('/utenti/transazionioggi/<string:email>/<string:oggi>', methods=['GET'], endpoint='get_transazionioggi')
def get_transazionioggi(email,oggi):
    connection = db.getdb()
    try:
        resp = []
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM transazioni WHERE email = %s AND tipo = %s AND data_esecuzione > %s; DATE(FROM_UNIXTIME(data_esecuzione)) = CURDATE()", (email,"Pagamento",oggi,))
        transazioni = cursor.fetchall()
        for transazione in transazioni:
            resp.append({
                'email': transazione['email'],
                'tipo': transazione['tipo'],
                'quantita': transazione['quantita'],
                'data': transazione['data_esecuzione']
            })
    except IntegrityError as e:
        resp = {}
        logging.error(f"IntegrityError occurred: {e}")
    except Exception as e:
        resp = {}
        logging.error(f"An error occurred: {e}")
    finally:
        cursor.close()
    return jsonify(resp)


@bp.route('/utenti/avvisi', methods=['GET'], endpoint='get_avvisi')
def get_avvisi():
    connection = db.getdb()
    resp = []
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM avvisi")
        avvisi = cursor.fetchall()
        for avviso in avvisi:
            resp.append({
                'id': avviso['id'],
                'titolo': avviso['titolo'], 
                'testo': avviso['testo'], 
                'data': avviso['data_attuale']
            })
    except IntegrityError:
        resp.append({'error': 'Error retrieving hotels'})
    finally:        
        cursor.close()
    return jsonify(resp)

@bp.route('/utenti/ultimoavviso', methods=['GET'], endpoint='get_ultimoavviso')
def get_ultimoavviso():
    connection = db.getdb()
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM avvisi WHERE data_attuale = (SELECT MAX(data_attuale) FROM avvisi)")
        avviso = cursor.fetchone()
        resp = {
            'titolo': avviso['titolo'],
            'testo': avviso['testo'],
            'data': avviso['data_attuale']
        }
    except IntegrityError:
        resp = {}
    finally:
        cursor.close()
    return jsonify(resp)



@bp.route('/img/<path:filename>', endpoint='flask_img')
def flask_img(filename):
    return current_app.send_static_file("img/" + filename)

@bp.route('/utenti/pastiprimi/<string:giorno>', methods=['GET'], endpoint='get_pastiprimi')
def get_pastiprimi(giorno):
    connection = db.getdb()
    resp = []
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM pasti WHERE tipo = 'Primo' AND giorno = %s",(giorno,))
        pasti = cursor.fetchall()
        for pasto in pasti:
            resp.append({
                'nome': pasto['nome'], 
                'allergie': pasto['allergie'],
                'tipo': pasto['tipo']
            })
    except IntegrityError:
        resp.append({'error': 'Error retrieving hotels'})
    finally:        
        cursor.close()
    return jsonify(resp)




@bp.route('/utenti/pastisecondi/<string:giorno>', methods=['GET'], endpoint='get_pastisecondi')
def get_pastisecondi(giorno):
    connection = db.getdb()
    resp = []
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM pasti WHERE tipo = 'Secondo' AND giorno = %s",(giorno,))
        pasti = cursor.fetchall()
        for pasto in pasti:
            resp.append({
                'nome': pasto['nome'], 
                'allergie': pasto['allergie'],
                'tipo': pasto['tipo']
            })
    except IntegrityError:
        resp.append({'error': 'Error retrieving hotels'})
    finally:        
        cursor.close()
    return jsonify(resp)

@bp.route('/utenti/pasticontorni/<string:giorno>', methods=['GET'], endpoint='get_pasticontorni')
def get_pasticontorni(giorno):
    connection = db.getdb()
    resp = []
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM pasti WHERE tipo = 'Contorno' AND giorno = %s",(giorno,))
        pasti = cursor.fetchall()
        for pasto in pasti:
            resp.append({
                'nome': pasto['nome'], 
                'allergie': pasto['allergie'],
                'tipo': pasto['tipo']
            })
    except IntegrityError:
        resp.append({'error': 'Error retrieving hotels'})
    finally:        
        cursor.close()
    return jsonify(resp)