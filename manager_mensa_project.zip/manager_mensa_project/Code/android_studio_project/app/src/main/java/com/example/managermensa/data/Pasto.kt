package com.example.managermensa.data

data class Pasto( val nome: String, val tipo: String,val allergie: List<String>)
