package com.example.managermensa.data

data class Prenotazione(
    val email: String,
    val data: String
)
