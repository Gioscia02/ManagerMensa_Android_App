package com.example.managermensa.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Allergia( @PrimaryKey  val nome: String)
