package com.example.managermensa.data

data class Transazione(val email: String, val data: String, val tipoOperazione: String, val quantita: String,)
