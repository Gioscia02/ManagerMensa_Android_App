package com.example.managermensa.activity.localdatabase


data class Prenotazioni(

    val id : Int,
    var email : String,
    var giorno : String,
    var orario : String,
    var pasto : String,

)