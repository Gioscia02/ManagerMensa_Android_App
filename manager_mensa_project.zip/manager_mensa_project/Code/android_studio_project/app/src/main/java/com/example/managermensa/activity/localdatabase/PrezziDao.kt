package com.example.managermensa.activity.localdatabase

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface PrezziDao {


}