-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: pwm
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `avvisi`
--

DROP TABLE IF EXISTS `avvisi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avvisi` (
  `id` int NOT NULL AUTO_INCREMENT,
  `titolo` varchar(255) NOT NULL,
  `testo` text NOT NULL,
  `data_attuale` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avvisi`
--

LOCK TABLES `avvisi` WRITE;
/*!40000 ALTER TABLE `avvisi` DISABLE KEYS */;
INSERT INTO `avvisi` VALUES (2,'Chiusura temporanea','La struttura sarà chiusa per manutenzione straordinaria.','2024-05-31 22:01:40'),(3,'Cambio orario','A partire da domani, gli orari di apertura saranno modificati. Controlla il nuovo calendario sul sito web.','2024-05-31 22:01:40'),(4,'Evento speciale','Non perdere l\'evento speciale organizzato per celebrare l\'anniversario della struttura.','2024-05-31 22:01:40'),(5,'Chiusura Straordinaria','La mensa sarà chiusa il 15 giugno per lavori di manutenzione. Ci scusiamo per il disagio.','2024-06-01 08:18:50'),(6,'Nuovo Menu Estivo','Dal 1 luglio, introdurremo un nuovo menu estivo con piatti freschi e leggeri.','2024-06-01 08:18:50'),(7,'Evento Speciale','Venerdì 25 giugno, ospiteremo una cena a tema internazionale con specialità da tutto il mondo.','2024-06-01 08:18:50'),(8,'Cambio Orario','A partire dal 1 settembre, la mensa aprirà alle 7:30 e chiuderà alle 21:00.','2024-06-01 08:18:50'),(9,'Promozione Studenti','Mostra il tuo tesserino universitario per ottenere uno sconto del 10% su tutti i pasti dal 1 al 15 giugno.','2024-06-07 10:00:00');
/*!40000 ALTER TABLE `avvisi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotels`
--

DROP TABLE IF EXISTS `hotels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hotels` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hotel_name` varchar(255) DEFAULT NULL,
  `addressline1` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `star_rating` decimal(3,1) DEFAULT NULL,
  `checkin` varchar(255) DEFAULT NULL,
  `checkout` varchar(255) DEFAULT NULL,
  `numberrooms` int DEFAULT NULL,
  `overview` text,
  `number_of_reviews` int DEFAULT NULL,
  `rating_average` decimal(3,1) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `rates_currency` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotels`
--

LOCK TABLES `hotels` WRITE;
/*!40000 ALTER TABLE `hotels` DISABLE KEYS */;
INSERT INTO `hotels` VALUES (1,'Hotel Sunshine','123 Sunshine St','Springfield','IL','USA',4.5,'3:00 PM','11:00 AM',120,'A luxurious hotel with all modern amenities.',250,4.3,'sunshine.jpg','USD'),(2,'Mountain View Inn','456 Mountain Rd','Denver','CO','USA',3.8,'4:00 PM','10:00 AM',80,'A cozy inn with stunning mountain views.',150,3.9,'mountain_view.jpg','USD'),(3,'Beachside Resort','789 Ocean Ave','Miami','FL','USA',5.0,'2:00 PM','12:00 PM',200,'A beachfront resort with amazing facilities.',500,4.7,'beachside.jpg','USD'),(4,'City Central Hotel','101 Main St','New York','NY','USA',4.2,'3:00 PM','11:00 AM',250,'A modern hotel in the heart of the city.',300,4.1,'city_central.jpg','USD'),(5,'Lakeside Lodge','102 Lakeview Dr','Chicago','IL','USA',3.5,'5:00 PM','10:00 AM',60,'A charming lodge by the lake.',120,3.7,'lakeside.jpg','USD'),(6,'Desert Oasis','103 Desert Rd','Phoenix','AZ','USA',4.0,'4:00 PM','11:00 AM',90,'A tranquil oasis in the desert.',180,4.0,'desert_oasis.jpg','USD'),(7,'Forest Retreat','104 Forest Ln','Portland','OR','USA',4.8,'2:00 PM','12:00 PM',50,'A peaceful retreat in the forest.',90,4.6,'forest_retreat.jpg','USD'),(8,'Urban Stay','105 Downtown St','San Francisco','CA','USA',4.1,'3:00 PM','11:00 AM',150,'A stylish hotel in the downtown area.',200,4.2,'urban_stay.jpg','USD'),(9,'Countryside Inn','106 Country Rd','Nashville','TN','USA',3.9,'4:00 PM','10:00 AM',70,'A quaint inn in the countryside.',140,4.0,'countryside.jpg','USD'),(10,'Riverside Hotel','107 River St','Austin','TX','USA',4.4,'3:00 PM','11:00 AM',110,'A beautiful hotel by the river.',220,4.5,'riverside.jpg','USD');
/*!40000 ALTER TABLE `hotels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pasti`
--

DROP TABLE IF EXISTS `pasti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pasti` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `allergie` varchar(255) DEFAULT NULL,
  `tipo` varchar(255) NOT NULL,
  `tipo_int` int DEFAULT NULL,
  `giorno` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pasti`
--

LOCK TABLES `pasti` WRITE;
/*!40000 ALTER TABLE `pasti` DISABLE KEYS */;
INSERT INTO `pasti` VALUES (56,'Spaghetti alla carbonara','Glutine, Uova','Primo',1,'Lunedi'),(57,'Lasagna','Glutine, Latte','Primo',1,'Lunedi'),(58,'Risotto ai funghi','Latte','Primo',1,'Lunedi'),(59,'Pollo arrosto','','Secondo',2,'Lunedi'),(60,'Braciola di maiale','','Secondo',2,'Lunedi'),(61,'Salmone alla griglia','','Secondo',2,'Lunedi'),(62,'Insalata verde','','Contorno',3,'Lunedi'),(63,'Patate al forno','','Contorno',3,'Lunedi'),(64,'Zucchine grigliate','','Contorno',3,'Lunedi'),(65,'Pasta al pesto','Glutine','Primo',1,'Martedi'),(66,'Gnocchi al ragù','Glutine','Primo',1,'Martedi'),(67,'Ravioli di zucca','Glutine, Latte','Primo',1,'Martedi'),(68,'Bistecca di manzo','','Secondo',2,'Martedi'),(69,'Polpette al sugo','Glutine, Uova','Secondo',2,'Martedi'),(70,'Trota al forno','','Secondo',2,'Martedi'),(71,'Spinaci saltati','','Contorno',3,'Martedi'),(72,'Carote lesse','','Contorno',3,'Martedi'),(73,'Peperoni grigliati','','Contorno',3,'Martedi'),(74,'Penne all\'arrabbiata','Glutine','Primo',1,'Mercoledi'),(75,'Minestrone','','Primo',1,'Mercoledi'),(76,'Risotto allo zafferano','Latte','Primo',1,'Mercoledi'),(77,'Costolette di agnello','','Secondo',2,'Mercoledi'),(78,'Cotolette di pollo','Glutine, Uova','Secondo',2,'Mercoledi'),(79,'Orata al cartoccio','','Secondo',2,'Mercoledi'),(80,'Melanzane alla parmigiana','Latte','Contorno',3,'Mercoledi'),(81,'Fagiolini lessi','','Contorno',3,'Mercoledi'),(82,'Pomodori gratinati','Glutine','Contorno',3,'Mercoledi'),(83,'Spaghetti alle vongole','Glutine','Primo',1,'Giovedi'),(84,'Tagliatelle al ragù','Glutine','Primo',1,'Giovedi'),(85,'Ravioli ricotta e spinaci','Glutine, Latte','Primo',1,'Giovedi'),(86,'Scaloppine al limone','Latte','Secondo',2,'Giovedi'),(87,'Involtini di vitello','Glutine, Uova','Secondo',2,'Giovedi'),(88,'Merluzzo fritto','Glutine','Secondo',2,'Giovedi'),(89,'Broccoli al vapore','','Contorno',3,'Giovedi'),(90,'Cavolfiore gratinato','Latte, Glutine','Contorno',3,'Giovedi'),(91,'Piselli in umido','','Contorno',3,'Giovedi'),(92,'Pasta e fagioli','Glutine','Primo',1,'Venerdi'),(93,'Risotto ai frutti di mare','','Primo',1,'Venerdi'),(94,'Penne al salmone','Glutine, Latte','Primo',1,'Venerdi'),(95,'Hamburger di manzo','','Secondo',2,'Venerdi'),(96,'Pollo alla cacciatora','','Secondo',2,'Venerdi'),(97,'Seppie in umido','','Secondo',2,'Venerdi'),(98,'Insalata di pomodori','','Contorno',3,'Venerdi'),(99,'Zucchine trifolate','','Contorno',3,'Venerdi'),(100,'Melanzane fritte','Glutine','Contorno',3,'Venerdi'),(101,'Pasta al ragù','Glutine','Primo',1,'Sabato'),(102,'Ravioli di carne','Glutine, Uova','Primo',1,'Sabato'),(103,'Gnocchi alla sorrentina','Glutine, Latte','Primo',1,'Sabato'),(104,'Costolette di maiale','','Secondo',2,'Sabato'),(105,'Pollo al curry','Latte','Secondo',2,'Sabato'),(106,'Sogliola alla mugnaia','','Secondo',2,'Sabato'),(107,'Insalata mista','','Contorno',3,'Sabato'),(108,'Patate lesse','','Contorno',3,'Sabato'),(109,'Carciofi trifolati','','Contorno',3,'Sabato'),(110,'Lasagne al forno','Glutine, Latte','Primo',1,'Domenica'),(111,'Cannelloni ricotta e spinaci','Glutine, Latte','Primo',1,'Domenica'),(112,'Risotto agli asparagi','Latte','Primo',1,'Domenica'),(113,'Arrosto di manzo','','Secondo',2,'Domenica'),(114,'Pollo fritto','Glutine, Uova','Secondo',2,'Domenica'),(115,'Baccalà alla vicentina','Glutine','Secondo',2,'Domenica'),(116,'Zucchine alla scapece','','Contorno',3,'Domenica'),(117,'Peperoni in agrodolce','','Contorno',3,'Domenica'),(118,'Insalata di rucola','','Contorno',3,'Domenica'),(119,'Riso saltato alla soia','Soia','Primo',1,'Lunedi'),(120,'Pollo alla teriyaki','Soia','Secondo',2,'Lunedi'),(121,'Insalata asiatica','Soia','Contorno',3,'Lunedi'),(122,'Noodles con verdure e salsa di soia','Soia','Primo',1,'Martedi'),(123,'Maiale in salsa di soia','Soia','Secondo',2,'Martedi'),(124,'Verdure saltate alla soia','Soia','Contorno',3,'Martedi'),(125,'Tofu alla griglia','Soia','Primo',1,'Mercoledi'),(126,'Salmone teriyaki','','Secondo',2,'Mercoledi'),(127,'Zuppa miso','Soia','Contorno',3,'Mercoledi'),(128,'Involtini primavera con salsa di soia','Soia','Primo',1,'Giovedi'),(129,'Manzo in padella con salsa di soia','Soia','Secondo',2,'Giovedi'),(130,'Riso fritto con verdure','','Contorno',3,'Giovedi'),(131,'Spiedini di pollo alla soia','Soia','Primo',1,'Venerdi'),(132,'Salmone alla griglia con salsa di soia','Soia','Secondo',2,'Venerdi'),(133,'Insalata di alghe con salsa di soia','Soia','Contorno',3,'Venerdi'),(134,'Pasta con tofu e verdure','Soia','Primo',1,'Sabato'),(135,'Anatra alla pechinese','','Secondo',2,'Sabato'),(136,'Edamame','Soia','Contorno',3,'Sabato'),(137,'Wok di verdure con salsa di soia','Soia','Primo',1,'Domenica'),(138,'Sushi assortito','Soia','Secondo',2,'Domenica'),(139,'Insalata di soia','Soia','Contorno',3,'Domenica');
/*!40000 ALTER TABLE `pasti` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prenotazioni`
--

DROP TABLE IF EXISTS `prenotazioni`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prenotazioni` (
  `email` varchar(255) NOT NULL,
  `giorno` varchar(255) NOT NULL,
  `orario` varchar(255) DEFAULT NULL,
  `pasto` varchar(50) NOT NULL,
  PRIMARY KEY (`giorno`,`pasto`,`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prenotazioni`
--

LOCK TABLES `prenotazioni` WRITE;
/*!40000 ALTER TABLE `prenotazioni` DISABLE KEYS */;
INSERT INTO `prenotazioni` VALUES ('gdgd@c.com','2024-05-30','20:00:00','cena'),('giorgio@1.com','2024-05-30','20:00:00','cena'),('gdgd@c.com','2024-05-30','12:00:00','pranzo'),('giorgio@1.com','2024-05-30','12:00:00','pranzo'),('null','2024-05-31','20:00','cena'),('pippo@gmail.com','2024-05-31','21:00','cena'),('yhs@c.c','2024-05-31','20:00','cena'),('null','2024-05-31','12:00','pranzo'),('pippo@gmail.com','2024-05-31','12:00','pranzo'),('yhs@c.c','2024-05-31','12:00','pranzo'),('giorgio@1.com','2024-06-01','20:00','cena'),('h@gmail.com','2024-06-01','19:00','cena'),('giorgio@1.com','2024-06-01','12:00','pranzo'),('h@gmail.com','2024-06-01','12:00','pranzo'),('giorgio@1.com','2024-06-03','20:00','cena'),('giorgio@1.com','2024-06-03','12:00','pranzo'),('giorgio@1.com','2024-06-05','20:00','cena'),('h@gmail.com','2024-06-05','20:00','cena'),('hasnicreed@gmail.com','2024-06-05','20:00','cena'),('pippo@gmail.com','2024-06-05','20:00','cena'),('yhs@c.c','2024-06-05','19:00','cena'),('giorgio@1.com','2024-06-05','12:00','pranzo'),('h@gmail.com','2024-06-05','12:00','pranzo'),('hasnicreed@gmail.com','2024-06-05','12:00','pranzo'),('pippo@gmail.com','2024-06-05','12:00','pranzo'),('yhs@c.c','2024-06-05','12:00','pranzo'),('','2024-06-06','20:00','cena'),('giorgio@1.com','2024-06-06','20:00','cena'),('hasnicreed@gmail.com','2024-06-06','20:00','cena'),('pippo@gmail.com','2024-06-06','20:00','cena'),('','2024-06-06','12:00','pranzo'),('giorgio@1.com','2024-06-06','12:00','pranzo'),('h@gmail.com','2024-06-06','12:00','pranzo'),('hasnicreed@gmail.com','2024-06-06','12:00','pranzo'),('pippo@gmail.com','2024-06-06','12:00','pranzo'),('ryf@c.x','2024-06-06','12:00','pranzo'),('tyyfg@c.d','2024-06-06','12:00','pranzo'),('yeyye@cd.y','2024-06-06','12:00','pranzo'),('giorgio@1.com','2024-06-09','20:00','cena'),('tyyfg@c.d','2024-06-09','21:00','cena'),('giorgio@1.com','2024-06-09','12:00','pranzo'),('tyyfg@c.d','2024-06-09','12:00','pranzo'),('gdgd@c.com','2024-06-12','20:00','cena'),('','2024-06-12','12:00','pranzo'),('adriana@gm.com','2024-06-12','12:00','pranzo'),('gdgd@c.com','2024-06-12','12:00','pranzo'),('giorgio@1.com','2024-06-12','12:00','pranzo'),('h@gmail.com','2024-06-12','12:00','pranzo'),('hasnicreed@gmail.com','2024-06-12','12:00','pranzo'),('pippo@gmail.com','2024-06-12','12:00','pranzo'),('yhs@c.c','2024-06-12','12:00','pranzo');
/*!40000 ALTER TABLE `prenotazioni` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prezzi`
--

DROP TABLE IF EXISTS `prezzi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prezzi` (
  `id` int NOT NULL AUTO_INCREMENT,
  `prezzo_pranzo_completo` decimal(10,2) NOT NULL,
  `prezzo_cena_completa` decimal(10,2) NOT NULL,
  `prezzo_primo` decimal(10,2) NOT NULL,
  `prezzo_secondo` decimal(10,2) NOT NULL,
  `prezzo_contorno` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prezzi`
--

LOCK TABLES `prezzi` WRITE;
/*!40000 ALTER TABLE `prezzi` DISABLE KEYS */;
INSERT INTO `prezzi` VALUES (1,6.00,6.00,3.00,3.00,2.00);
/*!40000 ALTER TABLE `prezzi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `segnalazioni`
--

DROP TABLE IF EXISTS `segnalazioni`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `segnalazioni` (
  `id` int NOT NULL AUTO_INCREMENT,
  `argomento` varchar(255) NOT NULL,
  `testo` text NOT NULL,
  `data_creazione` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `segnalazioni`
--

LOCK TABLES `segnalazioni` WRITE;
/*!40000 ALTER TABLE `segnalazioni` DISABLE KEYS */;
INSERT INTO `segnalazioni` VALUES (1,'binding.argomentiSegnalazione.toString()','D','2024-05-23 10:23:36',NULL),(2,'android.widget.RadioGroup{632a5ce V.E...... ........ 55,194-915,666 #7f080257 app:id/argomenti_segnalazione aid=1073741824}','Fd','2024-05-23 10:24:12',NULL),(3,'Servizio','Pippa','2024-05-23 10:31:24',NULL),(4,'ManagerMensa','Tu','2024-05-23 10:34:41',NULL),(5,'Servizio','T','2024-05-23 10:36:35',NULL),(6,'Cucina','Hdj','2024-05-23 10:37:43',NULL),(7,'Servizio','Hdjs','2024-05-23 12:03:58',NULL),(8,'Cucina','Hug','2024-05-26 12:06:18',NULL),(9,'Cucina','Hug','2024-05-26 12:06:19',NULL),(10,'Cucina','Hug','2024-05-26 12:06:21',NULL),(11,'Cucina','Hug','2024-05-26 12:06:21',NULL),(12,'Cucina','Hug','2024-05-26 12:06:22',NULL),(13,'Cucina','Hug','2024-05-26 12:06:22',NULL),(14,'Struttura','Ciao','2024-05-26 12:07:59',NULL),(15,'Cucina','6','2024-05-26 17:03:13',NULL),(16,'Struttura','Provaaaa','2024-05-26 19:22:22','hasnicreed@gmail.com'),(17,'Servizio','O{ii','2024-05-30 12:09:43','gdgd@c.com'),(18,'ManagerMensa','5','2024-06-06 09:04:51','null');
/*!40000 ALTER TABLE `segnalazioni` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transazioni`
--

DROP TABLE IF EXISTS `transazioni`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transazioni` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `quantita` decimal(10,2) NOT NULL,
  `data_esecuzione` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=291 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transazioni`
--

LOCK TABLES `transazioni` WRITE;
/*!40000 ALTER TABLE `transazioni` DISABLE KEYS */;
INSERT INTO `transazioni` VALUES (1,'gdgd@c.com','Ricarica',20.00,'2024-05-31 22:04:04'),(2,'gdgd@c.com','Spesa',2.00,'2024-05-31 22:04:04'),(3,'gdgd@c.com','Spesa',2.00,'2024-05-31 22:04:04'),(4,'gdgd@c.com','Spesa',-2.00,'2024-05-31 22:04:04'),(5,'gdgd@c.com','Spesa',-2.00,'2024-05-31 22:04:04'),(6,'gdgd@c.com','Spesa',-2.00,'2024-05-31 22:04:04'),(7,'gdgd@c.com','Spesa',-2.00,'2024-05-31 22:04:04'),(8,'h@gmail.com','Spesa',-2.00,'2024-05-31 22:04:04'),(9,'gdgd@c.com','Pagamento',-2.00,'2024-06-01 16:03:16'),(10,'gdgd@c.com','Pagamento',-2.00,'2024-06-01 16:03:26'),(11,'gdgd@c.com','Pagamento',-2.00,'2024-06-01 16:05:58'),(12,'gdgd@c.com','Pagamento',-2.00,'2024-06-01 16:06:18'),(13,'gdgd@c.com','Pagamento',-2.00,'2024-06-01 16:06:22'),(14,'gdgd@c.com','Pagamento',2.00,'2024-06-01 16:07:41'),(15,'gdgd@c.com','Pagamento',2.00,'2024-06-01 16:07:43'),(16,'gdgd@c.com','Pagamento',2.00,'2024-06-01 16:07:45'),(17,'h@gmail.com','Pagamento',2.00,'2024-06-01 16:10:20'),(18,'h@gmail.com','Pagamento',2.00,'2024-06-01 16:10:22'),(19,'giorgio@1.com','Pagamento',2.00,'2024-06-01 16:17:33'),(20,'giorgio@1.com','Pagamento',2.00,'2024-06-01 16:42:15'),(21,'giorgio@1.com','Ricarica',2.00,'2024-06-02 13:57:17'),(22,'giorgio@1.com','Ricarica',2.00,'2024-06-02 14:03:30'),(23,'giorgio@1.com','Ricarica',2.00,'2024-06-02 14:03:34'),(24,'s','Ricarica',3.00,'2024-06-02 15:24:42'),(25,'s','Ricarica',3.00,'2024-06-02 15:26:37'),(26,'s','Ricarica',3.00,'2024-06-02 15:30:36'),(27,'s','Ricarica',6.00,'2024-06-02 15:30:52'),(28,'giorgio@1.com','Ricarica',6.00,'2024-06-02 15:33:09'),(29,'giorgio@1.com','Ricarica',1.00,'2024-06-02 15:33:23'),(30,'giorgio@1.com','Ricarica',1.00,'2024-06-02 15:34:44'),(31,'giorgio@1.com','Ricarica',1.00,'2024-06-02 15:35:19'),(32,'giorgio@1.com','Ricarica',1.00,'2024-06-02 15:35:49'),(33,'giorgio@1.com','Ricarica',1.00,'2024-06-02 15:39:29'),(34,'giorgio@1.com','Pagamento',6.00,'2024-06-02 19:14:16'),(35,'giorgio@1.com','Pagamento',6.00,'2024-06-02 19:14:28'),(36,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:14:53'),(37,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:17:29'),(38,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:19:58'),(39,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:19:59'),(40,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:22:10'),(41,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:22:32'),(42,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:22:34'),(43,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:22:37'),(44,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:24:43'),(45,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:24:51'),(46,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:25:57'),(47,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:26:09'),(48,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:26:14'),(49,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:26:55'),(50,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:26:58'),(51,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:27:00'),(52,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:27:01'),(53,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:28:23'),(54,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:28:26'),(55,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:28:26'),(56,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:28:36'),(57,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:28:45'),(58,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:28:48'),(59,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:28:49'),(60,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:28:52'),(61,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:35:21'),(62,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:55:41'),(63,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:55:48'),(64,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:59:46'),(65,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 19:59:52'),(66,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:06:08'),(67,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:06:09'),(68,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:06:12'),(69,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:06:37'),(70,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:06:39'),(71,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:06:40'),(72,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:06:41'),(73,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:06:42'),(74,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:06:46'),(75,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:06:47'),(76,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:07:00'),(77,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:07:06'),(78,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:07:08'),(79,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:07:09'),(80,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:07:13'),(81,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:07:48'),(82,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:07:49'),(83,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:07:54'),(84,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:07:55'),(85,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:07:56'),(86,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:07:56'),(87,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:07:57'),(88,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:07:58'),(89,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:07:58'),(90,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:07:59'),(91,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:07:59'),(92,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:08:00'),(93,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:08:03'),(94,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:11:11'),(95,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:11:17'),(96,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:11:17'),(97,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:11:18'),(98,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:11:19'),(99,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:11:20'),(100,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:11:21'),(101,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:11:22'),(102,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:11:25'),(103,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:11:26'),(104,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:11:26'),(105,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:14:15'),(106,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:14:18'),(107,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:16:04'),(108,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:16:06'),(109,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:16:31'),(110,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:25:23'),(111,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:25:26'),(112,'giorgio@1.com','Pagamento',-3.00,'2024-06-02 20:25:27'),(113,'giorgio@1.com','Pagamento',-3.00,'2024-06-02 20:25:28'),(114,'giorgio@1.com','Pagamento',-2.00,'2024-06-02 20:25:30'),(115,'giorgio@1.com','Ricarica',500.00,'2024-06-02 20:25:39'),(116,'giorgio@1.com','Ricarica',1.00,'2024-06-02 20:27:08'),(117,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:27:18'),(118,'giorgio@1.com','Pagamento',-2.00,'2024-06-02 20:29:19'),(119,'giorgio@1.com','Pagamento',-3.00,'2024-06-02 20:34:34'),(120,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:34:39'),(121,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:34:40'),(122,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:34:40'),(123,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:34:41'),(124,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:34:42'),(125,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:34:42'),(126,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:34:43'),(127,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:34:44'),(128,'giorgio@1.com','Pagamento',-6.00,'2024-06-02 20:34:45'),(129,'giorgio@1.com','Pagamento',-3.00,'2024-06-02 20:43:40'),(130,'giorgio@1.com','Pagamento',-2.00,'2024-06-02 20:43:50'),(131,'giorgio@1.com','Ricarica',50.00,'2024-06-03 08:01:36'),(132,'giorgio@1.com','Ricarica',1.00,'2024-06-03 08:01:43'),(133,'giorgio@1.com','Ricarica',1.00,'2024-06-03 08:04:13'),(134,'giorgio@1.com','Ricarica',1.00,'2024-06-03 08:04:41'),(135,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:07:09'),(136,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:07:15'),(137,'giorgio@1.com','Pagamento',-3.00,'2024-06-03 08:07:19'),(138,'giorgio@1.com','Pagamento',-3.00,'2024-06-03 08:07:24'),(139,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:07:26'),(140,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:09:16'),(141,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:11:17'),(142,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:11:19'),(143,'giorgio@1.com','Pagamento',-3.00,'2024-06-03 08:13:13'),(144,'giorgio@1.com','Ricarica',100.00,'2024-06-03 08:14:44'),(145,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:14:50'),(146,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:17:16'),(147,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:19:02'),(148,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:19:05'),(149,'giorgio@1.com','Pagamento',-3.00,'2024-06-03 08:20:51'),(150,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:20:56'),(151,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:21:07'),(152,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:21:11'),(153,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:21:42'),(154,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:21:56'),(155,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:22:09'),(156,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:22:09'),(157,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:23:11'),(158,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:23:28'),(159,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:23:54'),(160,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:23:59'),(161,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:27:19'),(162,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:27:21'),(163,'giorgio@1.com','Ricarica',100.00,'2024-06-03 08:30:14'),(164,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:30:18'),(165,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:30:22'),(166,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:30:24'),(167,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:34:08'),(168,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:35:11'),(169,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:36:15'),(170,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:36:19'),(171,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:38:08'),(172,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:41:32'),(173,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:48:34'),(174,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:48:37'),(175,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:48:38'),(176,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:49:30'),(177,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:51:15'),(178,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:51:38'),(179,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:51:45'),(180,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:54:33'),(181,'giorgio@1.com','Ricarica',333.00,'2024-06-03 08:54:42'),(182,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:55:00'),(183,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:57:18'),(184,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:59:15'),(185,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 08:59:49'),(186,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 09:03:18'),(187,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 09:05:08'),(188,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 09:05:09'),(189,'giorgio@1.com','Pagamento',-3.00,'2024-06-03 09:05:10'),(190,'giorgio@1.com','Pagamento',-3.00,'2024-06-03 09:05:11'),(191,'giorgio@1.com','Pagamento',-2.00,'2024-06-03 09:05:14'),(192,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 09:13:30'),(193,'giorgio@1.com','Ricarica',3.00,'2024-06-03 09:14:32'),(194,'giorgio@1.com','Pagamento',-3.00,'2024-06-03 09:23:09'),(195,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 09:24:34'),(196,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 09:24:37'),(197,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 09:24:39'),(198,'giorgio@1.com','Ricarica',54.00,'2024-06-03 11:49:04'),(199,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 12:35:11'),(200,'giorgio@1.com','Pagamento',-3.00,'2024-06-03 12:35:12'),(201,'giorgio@1.com','Pagamento',-3.00,'2024-06-03 12:35:13'),(202,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 12:35:14'),(203,'giorgio@1.com','Pagamento',-2.00,'2024-06-03 12:35:15'),(204,'giorgio@1.com','Pagamento',-2.00,'2024-06-03 12:35:15'),(205,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 12:35:16'),(206,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 12:35:16'),(207,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 12:35:16'),(208,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 12:35:16'),(209,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 12:35:17'),(210,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 12:35:17'),(211,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 12:35:17'),(212,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 12:35:17'),(213,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 12:35:17'),(214,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 12:35:18'),(215,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 12:35:18'),(216,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 12:35:18'),(217,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 12:35:34'),(218,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 12:35:34'),(219,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 12:35:35'),(220,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 12:35:35'),(221,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 12:35:35'),(222,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 12:35:35'),(223,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 12:35:35'),(224,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 12:35:35'),(225,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:10:20'),(226,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:10:20'),(227,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:10:22'),(228,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:13:23'),(229,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:13:25'),(230,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:14:03'),(231,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:14:23'),(232,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:14:28'),(233,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:15:12'),(234,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:15:16'),(235,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:15:30'),(236,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:16:36'),(237,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:19:03'),(238,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:19:11'),(239,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:20:27'),(240,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:22:43'),(241,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:30:11'),(242,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:30:15'),(243,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:40:42'),(244,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:48:44'),(245,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:51:43'),(246,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:52:08'),(247,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:53:56'),(248,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:55:29'),(249,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:56:43'),(250,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:57:09'),(251,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:58:10'),(252,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 13:59:00'),(253,'giorgio@1.com','Ricarica',1000.00,'2024-06-03 14:00:00'),(254,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 14:01:14'),(255,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 14:01:34'),(256,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 14:02:40'),(257,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 14:03:47'),(258,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 14:05:16'),(259,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 14:11:27'),(260,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 14:13:54'),(261,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 14:14:23'),(262,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 14:15:53'),(263,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 14:17:07'),(264,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 14:19:00'),(265,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 14:19:45'),(266,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 14:20:13'),(267,'giorgio@1.com','Pagamento',-6.00,'2024-06-03 14:27:06'),(268,'giorgio@1.com','Pagamento',-6.00,'2024-06-04 15:43:35'),(269,'pippo@gmail.com','Ricarica',3366.00,'2024-06-06 08:52:20'),(270,'pippo@gmail.com','Pagamento',-6.00,'2024-06-06 08:52:28'),(271,'pippo@gmail.com','Pagamento',-6.00,'2024-06-06 09:02:40'),(272,'pippo@gmail.com','Pagamento',-6.00,'2024-06-06 09:02:43'),(273,'pippo@gmail.com','Pagamento',-3.00,'2024-06-06 09:04:00'),(274,'giorgio@1.com','Pagamento',-6.00,'2024-06-06 09:35:06'),(275,'giorgio@1.com','Pagamento',-6.00,'2024-06-06 09:35:06'),(276,'giorgio@1.com','Pagamento',-6.00,'2024-06-06 09:35:07'),(277,'giorgio@1.com','Pagamento',-6.00,'2024-06-06 09:35:07'),(278,'giorgio@1.com','Pagamento',-6.00,'2024-06-06 09:35:07'),(279,'giorgio@1.com','Pagamento',-6.00,'2024-06-06 09:35:07'),(280,'giorgio@1.com','Pagamento',-6.00,'2024-06-06 09:35:07'),(281,'giorgio@1.com','Pagamento',-6.00,'2024-06-06 10:12:44'),(282,'giorgio@1.com','Pagamento',-6.00,'2024-06-06 10:20:22'),(283,'h@gmail.com','Pagamento',-2.00,'2024-06-06 15:06:44'),(284,'giorgio@1.com','Pagamento',-2.00,'2024-06-06 15:28:52'),(285,'giorgio@1.com','Pagamento',-2.00,'2024-06-06 15:29:02'),(286,'tyyfg@c.d','Ricarica',1.00,'2024-06-09 14:07:03'),(287,'giorgio@1.com','Pagamento',-6.00,'2024-06-09 14:42:39'),(288,'giorgio@1.com','Pagamento',-6.00,'2024-06-12 09:06:57'),(289,'gdgd@c.com','Pagamento',-2.00,'2024-06-12 17:47:10'),(290,'adriana@gm.com','Ricarica',30.00,'2024-06-12 17:48:26');
/*!40000 ALTER TABLE `transazioni` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utenti`
--

DROP TABLE IF EXISTS `utenti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `utenti` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) NOT NULL,
  `cognome` varchar(50) NOT NULL,
  `nascita` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utenti`
--

LOCK TABLES `utenti` WRITE;
/*!40000 ALTER TABLE `utenti` DISABLE KEYS */;
INSERT INTO `utenti` VALUES (1,'Mario','Rossi','1980-01-15','mario.rossi@example.com',NULL),(2,'Luigi','Bianchi','1985-02-20','luigi.bianchi@example.com',NULL),(3,'Anna','Verdi','1990-03-25','anna.verdi@example.com',NULL),(4,'Giulia','Neri','1995-04-30','giulia.neri@example.com',NULL),(5,'Marco','Gialli','2000-05-10','marco.gialli@example.com',NULL),(6,'Giorgio','Sciacca','2002-05-24',NULL,'pippo.1'),(7,'Giorgio','Sciacca','2002-05-24','giorgiosciacca2405@gmail.com','pippo.1'),(8,'Luigi','Rossi ','2000-05-22','tomscomputer1@gmail.com','xxx'),(9,'H','H','09/05/2024','b','h'),(10,'Hasni','Mohamed','18/03/2003','hasnicreed@gmail.com','giorgiosei scemo'),(11,'Gh','Vh','16/05/2024','fh','n'),(12,'G','J','17/05/2024','giorgio.sciacca@you.unipa.it','v'),(13,'Gabriele ','Palma','26/05/2002','pippo@gmail.com','baudo'),(14,'Yy','Y','26/05/2024','b@gmail.com','w'),(18,'H','G','26/05/2024','h@gmail.com','g'),(23,'G','H','26/05/2024','fg@hm.com','v'),(29,'Yye','Hshs','02/05/2024','zh@g.com','hd'),(33,'Gufu','G','01/05/2024','ggfg@v.com','vhvh'),(35,'Urti5o','Utito6','07/05/2024','tyffh@dvf.it','djfj'),(36,'Hehjeb','Ohjh','07/05/2024','ffdff.@d.it','jndndn'),(37,'Uhjh','Jbh','26/05/2024','idjjd@d.it','jdjjd'),(38,'Bs','Ddxx','02/05/2014','xx@c.com','dxz'),(39,'Vrrv','Cd D','16/05/2014','cxc@f.com','xsvv'),(40,'Get H','Hbhh','13/05/2014','bjb@cc.com','hdjdb'),(41,'Titti','Hhh','07/05/2014','gjv@fm.con','jzjbs'),(42,'Ooo','Hhhg','07/05/2014','hug@gm.con','hjdhd'),(43,'Hhh','Hhvhg','17/05/2014','sghs@xhhd.com','djd'),(44,'Hejh','Hjhhh','14/05/2014','gjb@f.vom','fjdn'),(45,'Giorgio','Sciacca ','27/05/2014','giorgio@1.com','pippo'),(46,'Gigi','Hj','13/05/2014','hk@fj.vom',NULL),(47,'G','G','16/05/2014','gdudh@fj.vom',NULL),(48,'Yd','D','15/05/2014','gdgd@c.com','1'),(49,'1','1','30/05/2014','hekejh1@e.com','1'),(50,'4','4','24/06/22','l@c.co@','2'),(51,'Ma ','Y','30/05/2014','gd@2.com','s'),(52,'T','T','31/05/2014','gdh@c.co','1'),(53,'Ma ','9','31/05/2014','ydu@c.conm','w'),(54,'9','99','31/05/2014','ysys@c.oc','6'),(55,'Also','Alsi','31/05/2014','also@c.co','6'),(56,'Rr','Te','31/05/2014','hsh@c.cc','3'),(58,'P','Pp','31/05/2014','yhs@c.c','s'),(59,'Jkj','Jjb','31/05/2014','hsj@cc.c','sh'),(60,'T','T','06/06/2014','ryf@c.x','5'),(61,'Tu','Gg','06/06/2014','yeyye@cd.y','g'),(62,'Fy','Gh','02/06/2014','tyyfg@c.d','yeiei'),(63,'Adriana ','Azzarello','16/08/1962','adriana@gm.com','1234');
/*!40000 ALTER TABLE `utenti` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'pwm'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-17  0:24:21
